import { readFile } from "node:fs/promises";
import AxeBuilder from "@axe-core/playwright";
import { expect, type Page, type TestInfo, test } from "@playwright/test";
import sources from "../../data/nhc-milton/sources.json" with { type: "json" };

const first = sources[0];
const second = sources[1];
if (!first || !second) throw new Error("Missing annotation source fixtures.");
const storageKey = "frt.notebook./annotations/.nhc-milton.v1";

async function selectPassage(page: Page, passage = "Scatterometer data around midday confirmed") {
  const source = page.getByLabel("Original bulletin text", { exact: true });
  await source.focus();
  await source.evaluate((node, quote) => {
    const textarea = node as HTMLTextAreaElement;
    const start = textarea.value.indexOf(quote);
    if (start < 0) throw new Error("Passage not found");
    textarea.setSelectionRange(start, start);
  }, passage);
  // The keyboard extends the native selection; Annotate must retain it after focus changes.
  await page.keyboard.down("Shift");
  for (let index = 0; index < passage.length; index++) await page.keyboard.press("ArrowRight");
  await page.keyboard.up("Shift");
  await page.getByRole("button", { name: "Annotate selection", exact: true }).click();
  await expect(page.locator("#quotation")).toHaveText(passage);
}
async function exportNotebook(page: Page, info: TestInfo, name: string) {
  const pending = page.waitForEvent("download");
  await page.getByRole("button", { name: "Export notebook", exact: true }).click();
  const path = info.outputPath(name);
  await (await pending).saveAs(path);
  return { path, value: JSON.parse(await readFile(path, "utf8")) };
}

test("archived passage annotation preserves exact source and reopens its actual download", async ({
  page,
  browser,
}, info) => {
  await page.goto("/annotations/");
  await expect(page.getByRole("heading", { name: "Forecast reading" })).toBeVisible();
  await expect(page.getByLabel("Original bulletin text", { exact: true })).toHaveValue(first.text);
  await expect(page.locator("#forecaster")).toHaveText("Brown");
  await page
    .getByLabel("Research question", { exact: true })
    .fill("How does the bulletin distinguish observation from prediction?");
  await selectPassage(page);
  await page
    .getByLabel("Interpretation", { exact: true })
    .fill("This passage names an observation instrument as evidence.");
  await page.getByLabel("Creator kind", { exact: true }).selectOption("human");
  await page.getByLabel("Creator name", { exact: true }).fill("Test researcher");
  await page.getByRole("button", { name: "Save annotation", exact: true }).click();
  const annotation = page.locator("#annotations li");
  await expect(annotation).toHaveCount(1);
  await annotation.getByRole("button", { name: "Return to quotation" }).click();
  const selection = await page.locator("#bulletin-text").evaluate((node) => {
    const control = node as HTMLTextAreaElement;
    return {
      start: control.selectionStart,
      end: control.selectionEnd,
      quote: control.value.slice(control.selectionStart, control.selectionEnd),
    };
  });
  const saved = await exportNotebook(page, info, "annotation-notebook.json");
  expect(saved.value.sources).toEqual(sources);
  expect(saved.value.annotations[0]).toMatchObject({
    ...selection,
    sourceId: first.id,
    creator: { kind: "human", name: "Test researcher" },
    review: null,
  });
  expect(first.text.slice(selection.start, selection.end)).toBe(selection.quote);
  await page.reload();
  await expect(page.locator("#annotations li")).toHaveCount(1);
  const context = await browser.newContext();
  const reopened = await context.newPage();
  await reopened.goto("/annotations/");
  reopened.once("dialog", (dialog) => dialog.accept());
  await reopened.getByLabel("Open notebook").setInputFiles(saved.path);
  await expect(reopened.locator("#notebook-status")).toHaveText("Saved locally");
  expect((await exportNotebook(reopened, info, "reopened-notebook.json")).value).toEqual(
    saved.value,
  );
  await context.close();
});

test("a changed interpretation clears its earlier explicit review", async ({ page }, info) => {
  await page.goto("/annotations/");
  await selectPassage(page);
  await page
    .getByLabel("Interpretation", { exact: true })
    .fill("The passage identifies a measured observation.");
  await page.getByLabel("Record a source-fit review", { exact: true }).check();
  await page.getByLabel("Reviewer kind", { exact: true }).selectOption("human");
  await page.getByLabel("Reviewer name", { exact: true }).fill("Test reviewer");
  await page
    .getByLabel("Review criterion", { exact: true })
    .fill("The quotation explicitly names measured source data.");
  await page
    .getByLabel("Does the quotation support this interpretation?", { exact: true })
    .selectOption("supports");
  await page.getByRole("button", { name: "Save annotation", exact: true }).click();
  await expect(page.locator("#annotations li")).toContainText("Source-fit review: Supports");
  const reviewed = await exportNotebook(page, info, "reviewed.json");
  expect(reviewed.value.annotations[0].review.reviewer.name).toBe("Test reviewer");
  await page.getByRole("button", { name: "Edit", exact: true }).click();
  await page
    .getByLabel("Interpretation", { exact: true })
    .fill("A changed interpretation requires another review.");
  await expect(page.locator("#review-change")).toContainText("previous review is cleared");
  await expect(page.getByLabel("Record a source-fit review", { exact: true })).not.toBeChecked();
  await page.getByRole("button", { name: "Save annotation", exact: true }).click();
  expect(
    (await exportNotebook(page, info, "review-cleared.json")).value.annotations[0].review,
  ).toBeNull();
});

test("unfinished annotations survive declined source changes and block export or replacement", async ({
  page,
}, info) => {
  await page.goto("/annotations/");
  await page.getByLabel("Research question", { exact: true }).fill("Keep this notebook");
  const saved = await exportNotebook(page, info, "before-pending.json");
  await selectPassage(page);
  await page
    .getByLabel("Interpretation", { exact: true })
    .fill("Keep this unfinished interpretation");
  page.once("dialog", (dialog) => dialog.dismiss());
  await page.getByLabel("Bulletin", { exact: true }).selectOption(second.id);
  await expect(page.getByLabel("Bulletin", { exact: true })).toHaveValue(first.id);
  await expect(page.getByLabel("Interpretation", { exact: true })).toHaveValue(
    "Keep this unfinished interpretation",
  );
  await page.getByRole("button", { name: "Export notebook", exact: true }).click();
  await expect(page.locator("#notebook-status")).toContainText("Save or discard");
  await page.getByLabel("Open notebook").setInputFiles(saved.path);
  await expect(page.locator("#notebook-status")).toContainText("Save or discard");
  await expect(page.getByLabel("Interpretation", { exact: true })).toHaveValue(
    "Keep this unfinished interpretation",
  );
  await page.getByRole("button", { name: "Cancel", exact: true }).click();
  await page.getByLabel("Bulletin", { exact: true }).selectOption(second.id);
  await expect(page).toHaveURL(new RegExp(second.id));
  await page.goBack();
  await expect(page.getByLabel("Bulletin", { exact: true })).toHaveValue(first.id);
  await expect(page.getByLabel("Original bulletin text", { exact: true })).toHaveValue(first.text);
});

test("rejected and cancelled imports preserve a valid notebook and accepted raw author strings", async ({
  page,
}, info) => {
  await page.goto("/annotations/");
  await selectPassage(page);
  await page.getByRole("button", { name: "Save annotation", exact: true }).click();
  const base = (await exportNotebook(page, info, "initial.json")).value;
  const payload = {
    ...base,
    researchQuestion: " First\r\nSecond ",
    annotations: [
      {
        ...base.annotations[0],
        note: " Note\r\nsecond ",
        creator: { kind: "unknown", name: " Unknown\r\nname " },
      },
    ],
  };
  const original = `${JSON.stringify(payload, null, 2)}\n`;
  page.once("dialog", (dialog) => dialog.accept());
  await page
    .getByLabel("Open notebook")
    .setInputFiles({
      name: "raw-author-text.json",
      mimeType: "application/json",
      buffer: Buffer.from(original),
    });
  await expect(page.locator("#notebook-status")).toHaveText("Saved locally");
  expect((await exportNotebook(page, info, "unmodified-author-text.json")).value).toEqual(payload);
  expect(await page.evaluate((key) => localStorage.getItem(key), storageKey)).toBe(original);
  const changedSource = structuredClone(payload);
  changedSource.sources[0].text += "changed";
  await page
    .getByLabel("Open notebook")
    .setInputFiles({
      name: "changed-source.json",
      mimeType: "application/json",
      buffer: Buffer.from(JSON.stringify(changedSource)),
    });
  await expect(page.locator("#notebook-status")).toContainText("Notebook not opened");
  expect((await exportNotebook(page, info, "after-rejected.json")).value).toEqual(payload);
  page.once("dialog", (dialog) => dialog.dismiss());
  await page
    .getByLabel("Open notebook")
    .setInputFiles({
      name: "valid-replacement.json",
      mimeType: "application/json",
      buffer: Buffer.from(JSON.stringify(base)),
    });
  expect((await exportNotebook(page, info, "after-cancelled.json")).value).toEqual(payload);
  await page.getByRole("button", { name: "Edit", exact: true }).click();
  await page.getByLabel("Category", { exact: true }).selectOption("uncertainty");
  await page.getByRole("button", { name: "Save annotation", exact: true }).click();
  expect((await exportNotebook(page, info, "category-only-edit.json")).value).toEqual({
    ...payload,
    annotations: [{ ...payload.annotations[0], category: "uncertainty" }],
  });
});

test("corrupt and externally changed saved copies remain recoverable without overwrite", async ({
  page,
  context,
}, info) => {
  await page.addInitScript(({ key }) => localStorage.setItem(key, ""), { key: storageKey });
  await page.goto("/annotations/");
  await expect(page.locator("#notebook-status")).toContainText("could not be opened");
  await page.getByLabel("Research question", { exact: true }).fill("Recover this work");
  expect(await page.evaluate((key) => localStorage.getItem(key), storageKey)).toBe("");
  expect((await exportNotebook(page, info, "corrupt-recovery.json")).value.researchQuestion).toBe(
    "Recover this work",
  );
  const other = await context.newPage();
  await other.goto("/annotations/");
  await other.evaluate((key) => localStorage.setItem(key, "external bytes"), storageKey);
  await expect(page.locator("#notebook-status")).toContainText("Another tab changed");
  await page.getByLabel("Research question", { exact: true }).fill("Recovered after conflict");
  expect(await page.evaluate((key) => localStorage.getItem(key), storageKey)).toBe(
    "external bytes",
  );
  expect((await exportNotebook(page, info, "conflict-recovery.json")).value.researchQuestion).toBe(
    "Recovered after conflict",
  );
  await other.close();
});

test("narrow reading and annotation controls are keyboard accessible and reflow", async ({
  page,
}, info) => {
  await page.setViewportSize({ width: 320, height: 800 });
  await page.goto("/annotations/");
  await page.getByRole("button", { name: "Annotate selection", exact: true }).click();
  await expect(page.locator("#selection-status")).toContainText("Select a passage");
  await expect(page.getByLabel("Original bulletin text", { exact: true })).toBeFocused();
  await selectPassage(page);
  await expect(page.getByLabel("Category", { exact: true })).toBeFocused();
  await page.getByLabel("Record a source-fit review", { exact: true }).check();
  expect((await new AxeBuilder({ page }).analyze()).violations).toEqual([]);
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  await page.screenshot({ path: info.outputPath("annotation-narrow.png"), fullPage: true });
  await page.evaluate(() => {
    document.documentElement.style.fontSize = "200%";
  });
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  await page.getByRole("button", { name: "Cancel", exact: true }).click();
  await expect(page.getByRole("button", { name: "Annotate selection", exact: true })).toBeFocused();
});
