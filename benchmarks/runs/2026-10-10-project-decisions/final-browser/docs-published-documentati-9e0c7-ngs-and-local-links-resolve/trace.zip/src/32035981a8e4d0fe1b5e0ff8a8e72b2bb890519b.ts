import AxeBuilder from "@axe-core/playwright";
import { expect, test } from "@playwright/test";

test("published documentation routes, headings and local links resolve", async ({
  page,
  request,
}) => {
  await page.goto("/");
  await expect(page.getByRole("heading", { level: 1 })).toHaveText("Fancy Research Tools");
  const routes = await page
    .locator(".docs-nav a")
    .evaluateAll((links) =>
      links
        .map((link) => (link as HTMLAnchorElement).href)
        .filter((href) => href.startsWith(location.origin)),
    );
  for (const route of routes) {
    await page.goto(route);
    const ids = await page
      .locator("[id]")
      .evaluateAll((elements) => elements.map((element) => element.id));
    expect(new Set(ids).size, route).toBe(ids.length);
    const links = await page
      .locator("main a")
      .evaluateAll((elements) =>
        elements
          .map((element) => (element as HTMLAnchorElement).href)
          .filter((href) => href.startsWith(location.origin)),
      );
    for (const link of links) {
      const response = await request.get(link);
      expect(response.status(), link).toBe(200);
      if (new URL(link).pathname.endsWith(".html"))
        expect(await response.text(), link).toContain("<!doctype html>");
      const hash = new URL(link).hash;
      if (hash) {
        const html = await response.text();
        const exists = await page.evaluate(
          ({ html, id }) =>
            new DOMParser().parseFromString(html, "text/html").getElementById(id) !== null,
          { html, id: decodeURIComponent(hash.slice(1)) },
        );
        expect(exists, `Missing fragment: ${link}`).toBe(true);
      }
    }
  }
  await page.goto("/reference/specification.html");
  expect((await new AxeBuilder({ page }).analyze()).violations).toEqual([]);
  await page.screenshot({ path: "test-results/documentation-desktop.png", fullPage: true });
  await page.setViewportSize({ width: 320, height: 800 });
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  await page.screenshot({ path: "test-results/documentation-mobile.png", fullPage: true });
  await page.goto("/");
  await expect(page.locator("details.docs-nav")).not.toHaveAttribute("open");
  await page.getByText("Documentation", { exact: true }).click();
  await page.getByRole("link", { name: "Design", exact: true }).first().click();
  await expect(page.getByRole("heading", { name: "Design", exact: true })).toBeVisible();
  await page.getByText("On this page", { exact: true }).first().click();
  await page.getByRole("link", { name: "Information visualisation", exact: true }).click();
  await expect(page).toHaveURL(/#information-visualisation$/);
});

test("relative assets and navigation work below a repository subpath", async ({ page }) => {
  await page.route("**/fancy-research-tools/**", (route) => {
    const url = new URL(route.request().url());
    url.pathname = url.pathname.replace("/fancy-research-tools", "");
    return route.continue({ url: url.href });
  });
  await page.goto("/fancy-research-tools/");
  await page.getByRole("link", { name: "Explore instruments", exact: true }).click();
  await expect(page).toHaveURL(/\/fancy-research-tools\/pilot\/$/);
  await expect(page.getByRole("main")).toBeVisible();
  await page.reload();
  await expect(page.getByRole("main")).toBeVisible();
});

test("narrow reference tables retain readable columns and keyboard scrolling", async ({ page }) => {
  await page.setViewportSize({ width: 320, height: 800 });
  await page.goto("/reference/design.html");
  const table = page.getByRole("region", {
    name: "Table: Surface, Primary content, Supporting content",
  });
  await expect(table).toBeVisible();
  expect(
    await table
      .locator("th")
      .first()
      .evaluate((node) => node.getBoundingClientRect().width),
  ).toBeGreaterThanOrEqual(160);
  expect(await table.evaluate((node) => node.scrollWidth > node.clientWidth)).toBe(true);
  await table.focus();
  await page.keyboard.press("ArrowRight");
  await expect.poll(() => table.evaluate((node) => node.scrollLeft)).toBeGreaterThan(0);
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
});
